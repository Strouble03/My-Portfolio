// Edit this file to update your portfolio content
window.PORTFOLIO = {
  basics: {
    name: "Alex Santos",
    title: "Quality Assurance (QA) Specialist",
    location: "Manila, Philippines",
    email: "alex.santos@example.com",
    phone: "+63 912 345 6789",
    linkedin: "https://www.linkedin.com/in/alexsantos",
    github: "https://github.com/alexsantos",
    summary: "QA Specialist with 3+ years experience in manual and automated testing for web and mobile apps. Skilled in test planning, API testing and writing clear defect reports."
  },
  skills: ["Manual Testing","Test Case Design","Exploratory Testing","Regression Testing","API Testing (Postman)","Automation (Cypress)","SQL"],
  tools: ["Jira","TestRail","Postman","Cypress","Selenium","Git","BrowserStack"],
  certifications: ["ISTQB Foundation Level (2022)"],
  experience: [
    {
      role: "QA Specialist",
      company: "TechSolutions Inc.",
      location: "Manila, PH",
      period: "Jan 2023 — Present",
      highlights: [
        "Maintained automated smoke suite reducing release verification time by 50%.",
        "Created and organized 200+ test cases in TestRail covering core flows."
      ]
    },
    {
      role: "Junior QA Tester",
      company: "WebApps Co.",
      location: "Manila, PH",
      period: "Jun 2021 — Dec 2022",
      highlights: [
        "Authored reproduction steps and provided logs/screenshots for high-severity issues.",
        "Improved regression checklist for payment and checkout modules."
      ]
    }
  ],
  projects: [
    {
      name: "Checkout Automation",
      period: "2024",
      link: "",
      tech: ["Cypress","GitHub Actions"],
      summary: "Automated end-to-end checkout flows and integrated smoke tests into CI."
    }
  ],
  testArtifacts: {
    testCases: [
      { title: "Login - valid credentials", note: "Positive path" },
      { title: "Checkout - card decline", note: "Negative case" }
    ],
    bugReports: [
      { id: "BUG-112", title: "Total mismatch after coupon", severity: "High" }
    ]
  }
};
